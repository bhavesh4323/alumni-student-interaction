"use client"

import type React from "react"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Textarea } from "@/components/ui/textarea"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Slider } from "@/components/ui/slider"
import { Switch } from "@/components/ui/switch"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Badge } from "@/components/ui/badge"
import { findMentors } from "@/app/actions"

export default function MentorshipForm() {
  const [formData, setFormData] = useState({
    careerStage: "",
    interests: "",
    skills: "",
    goals: "",
    preferredIndustry: "",
    commitmentLevel: 50,
    isVirtualOk: true,
  })

  const [isSubmitting, setIsSubmitting] = useState(false)
  const [isSuccess, setIsSuccess] = useState(false)
  const [matches, setMatches] = useState<any[]>([])

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target
    setFormData((prev) => ({ ...prev, [name]: value }))
  }

  const handleSelectChange = (name: string, value: string) => {
    setFormData((prev) => ({ ...prev, [name]: value }))
  }

  const handleSliderChange = (value: number[]) => {
    setFormData((prev) => ({ ...prev, commitmentLevel: value[0] }))
  }

  const handleSwitchChange = (checked: boolean) => {
    setFormData((prev) => ({ ...prev, isVirtualOk: checked }))
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setIsSubmitting(true)
    setMatches([])

    try {
      // Create FormData object
      const formDataObj = new FormData()
      formDataObj.append("careerStage", formData.careerStage)
      formDataObj.append("interests", formData.interests)
      formDataObj.append("skills", formData.skills)
      formDataObj.append("goals", formData.goals)
      formDataObj.append("preferredIndustry", formData.preferredIndustry)
      formDataObj.append("commitmentLevel", formData.commitmentLevel.toString())
      formDataObj.append("isVirtualOk", formData.isVirtualOk ? "on" : "off")

      // Call server action
      const result = await findMentors(formDataObj)

      if (result.success) {
        setIsSuccess(true)
        setMatches(result.matches)
      } else {
        throw new Error(result.error || "Failed to find mentors")
      }
    } catch (error) {
      console.error("Error finding mentors:", error)
    } finally {
      setIsSubmitting(false)
    }
  }

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle>Find Your Mentor Match</CardTitle>
        </CardHeader>
        <CardContent>
          <form onSubmit={handleSubmit} className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="careerStage">Current Career Stage</Label>
              <Select onValueChange={(value) => handleSelectChange("careerStage", value)} value={formData.careerStage}>
                <SelectTrigger id="careerStage">
                  <SelectValue placeholder="Select your current stage" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="student">Student</SelectItem>
                  <SelectItem value="fresher">Recent Graduate</SelectItem>
                  <SelectItem value="earlyCareer">Early Career (1-3 years)</SelectItem>
                  <SelectItem value="midCareer">Mid Career (4-10 years)</SelectItem>
                  <SelectItem value="experienced">Experienced Professional (10+ years)</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label htmlFor="interests">Areas of Interest</Label>
              <Textarea
                id="interests"
                name="interests"
                placeholder="E.g., Machine Learning, Web Development, IoT"
                value={formData.interests}
                onChange={handleChange}
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="skills">Skills You Want to Develop</Label>
              <Textarea
                id="skills"
                name="skills"
                placeholder="E.g., Python, Leadership, Public Speaking"
                value={formData.skills}
                onChange={handleChange}
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="goals">Mentorship Goals</Label>
              <Textarea
                id="goals"
                name="goals"
                placeholder="What do you hope to achieve through mentorship?"
                value={formData.goals}
                onChange={handleChange}
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="preferredIndustry">Preferred Industry</Label>
              <Select
                onValueChange={(value) => handleSelectChange("preferredIndustry", value)}
                value={formData.preferredIndustry}
              >
                <SelectTrigger id="preferredIndustry">
                  <SelectValue placeholder="Select preferred industry" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="tech">Technology</SelectItem>
                  <SelectItem value="healthcare">Healthcare</SelectItem>
                  <SelectItem value="finance">Finance</SelectItem>
                  <SelectItem value="education">Education</SelectItem>
                  <SelectItem value="manufacturing">Manufacturing</SelectItem>
                  <SelectItem value="government">Government</SelectItem>
                  <SelectItem value="other">Other</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label htmlFor="commitmentLevel">Time Commitment (hours per month): {formData.commitmentLevel}</Label>
              <Slider
                id="commitmentLevel"
                min={1}
                max={20}
                step={1}
                value={[formData.commitmentLevel]}
                onValueChange={handleSliderChange}
              />
            </div>

            <div className="flex items-center space-x-2">
              <Switch id="isVirtualOk" checked={formData.isVirtualOk} onCheckedChange={handleSwitchChange} />
              <Label htmlFor="isVirtualOk">I'm open to virtual mentorship</Label>
            </div>

            <Button type="submit" className="w-full" disabled={isSubmitting}>
              {isSubmitting ? "Finding Matches..." : "Find Mentor Matches"}
            </Button>
          </form>
        </CardContent>
        <CardFooter className="text-sm text-gray-500">
          Our AI algorithm will analyze your profile and preferences to suggest the most compatible mentors.
        </CardFooter>
      </Card>

      {isSuccess && matches.length > 0 && (
        <Card>
          <CardHeader>
            <CardTitle>Your Mentor Matches</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-6">
              {matches.map((match, index) => (
                <div key={index} className="flex flex-col md:flex-row gap-4 border-b pb-6 last:border-0 last:pb-0">
                  <div className="flex-shrink-0">
                    <Avatar className="h-16 w-16">
                      <AvatarImage src={match.mentor.profileImage} alt={match.mentor.name} />
                      <AvatarFallback>
                        {match.mentor.name
                          .split(" ")
                          .map((n: string) => n[0])
                          .join("")}
                      </AvatarFallback>
                    </Avatar>
                  </div>
                  <div className="flex-grow">
                    <div className="flex flex-col md:flex-row md:items-center md:justify-between">
                      <div>
                        <h3 className="font-medium text-lg">{match.mentor.name}</h3>
                        <p className="text-sm text-gray-500">
                          {match.mentor.title} at {match.mentor.company}
                        </p>
                      </div>
                      <div className="mt-2 md:mt-0">
                        <Badge variant="outline" className="bg-green-50 text-green-700 border-green-200">
                          {match.matchScore.toFixed(0)}% Match
                        </Badge>
                      </div>
                    </div>

                    <p className="mt-2 text-sm">{match.mentor.bio}</p>

                    <div className="mt-3">
                      <p className="text-sm font-medium">Why you match:</p>
                      <p className="text-sm text-gray-600">{match.compatibilityReason}</p>
                    </div>

                    <div className="mt-3 flex flex-wrap gap-2">
                      {match.mentor.skills.slice(0, 3).map((skill: string, i: number) => (
                        <Badge key={i} variant="secondary" className="text-xs">
                          {skill}
                        </Badge>
                      ))}
                    </div>

                    <div className="mt-4 flex space-x-2">
                      <Button size="sm">Request Mentorship</Button>
                      <Button size="sm" variant="outline">
                        View Profile
                      </Button>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  )
}

