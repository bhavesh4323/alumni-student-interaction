import { Card, CardContent } from "@/components/ui/card"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Badge } from "@/components/ui/badge"

export default function AlumniSpotlight() {
  const alumni = [
    {
      id: 1,
      name: "Priya Sharma",
      image: "/placeholder.svg?height=200&width=200",
      role: "Software Engineer",
      company: "Google",
      batch: "2015",
      expertise: ["AI/ML", "Cloud Computing", "Software Development"],
      quote:
        "The technical education I received in Rajasthan gave me a strong foundation to build my career in technology.",
    },
    {
      id: 2,
      name: "Rahul Verma",
      image: "/placeholder.svg?height=200&width=200",
      role: "Product Manager",
      company: "Microsoft",
      batch: "2012",
      expertise: ["Product Strategy", "UX Design", "Agile Methodologies"],
      quote: "I'm passionate about mentoring students and helping them navigate their early career challenges.",
    },
    {
      id: 3,
      name: "Ananya Patel",
      image: "/placeholder.svg?height=200&width=200",
      role: "Data Scientist",
      company: "Amazon",
      batch: "2017",
      expertise: ["Data Analysis", "Machine Learning", "Big Data"],
      quote:
        "The technical skills and problem-solving abilities I developed during my education have been invaluable in my career.",
    },
  ]

  return (
    <section className="py-12 bg-gray-50">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center">
          <h2 className="text-base text-primary font-semibold tracking-wide uppercase">Alumni Spotlight</h2>
          <p className="mt-2 text-3xl leading-8 font-extrabold tracking-tight text-gray-900 sm:text-4xl">
            Learn from industry leaders
          </p>
          <p className="mt-4 max-w-2xl text-xl text-gray-500 mx-auto">
            Connect with successful alumni who are making an impact in their fields and are ready to mentor the next
            generation.
          </p>
        </div>

        <div className="mt-10 grid gap-8 md:grid-cols-3">
          {alumni.map((person) => (
            <Card key={person.id} className="overflow-hidden">
              <CardContent className="p-6">
                <div className="flex flex-col items-center text-center">
                  <Avatar className="h-24 w-24 mb-4">
                    <AvatarImage src={person.image} alt={person.name} />
                    <AvatarFallback>
                      {person.name
                        .split(" ")
                        .map((n) => n[0])
                        .join("")}
                    </AvatarFallback>
                  </Avatar>
                  <h3 className="text-lg font-medium text-gray-900">{person.name}</h3>
                  <p className="text-sm text-gray-500">
                    {person.role} at {person.company}
                  </p>
                  <p className="text-xs text-gray-400 mt-1">Batch of {person.batch}</p>

                  <div className="mt-3 flex flex-wrap justify-center gap-2">
                    {person.expertise.map((skill) => (
                      <Badge key={skill} variant="secondary" className="text-xs">
                        {skill}
                      </Badge>
                    ))}
                  </div>

                  <blockquote className="mt-4 text-sm italic text-gray-600">"{person.quote}"</blockquote>

                  <button className="mt-4 text-primary text-sm font-medium hover:underline">
                    Connect with {person.name.split(" ")[0]}
                  </button>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </section>
  )
}

