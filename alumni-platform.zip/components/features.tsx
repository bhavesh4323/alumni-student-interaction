import { Users, Bot, Shield, MessageSquare, Calendar, TrendingUp } from "lucide-react"

export default function Features() {
  const features = [
    {
      name: "Blockchain-Verified Profiles",
      description:
        "Secure alumni database with blockchain authentication to prevent fake profiles and ensure data integrity.",
      icon: Shield,
    },
    {
      name: "AI-Powered Matching",
      description:
        "Connect with alumni and students based on shared interests, industry experience, and skills using advanced NLP algorithms.",
      icon: Users,
    },
    {
      name: "Intelligent Chatbot",
      description:
        "Get instant career advice, platform navigation help, and automated responses using our Rasa & spaCy powered AI assistant.",
      icon: Bot,
    },
    {
      name: "Interactive Forums",
      description:
        "Engage in meaningful discussions, seek advice, and share knowledge in moderated topic-based forums.",
      icon: MessageSquare,
    },
    {
      name: "Event Management",
      description:
        "Discover and participate in networking events, workshops, and webinars organized by alumni and the department.",
      icon: Calendar,
    },
    {
      name: "Engagement Analytics",
      description:
        "AI-driven insights on platform engagement, trending discussions, and personalized content recommendations.",
      icon: TrendingUp,
    },
  ]

  return (
    <div className="py-12 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="lg:text-center">
          <h2 className="text-base text-primary font-semibold tracking-wide uppercase">Features</h2>
          <p className="mt-2 text-3xl leading-8 font-extrabold tracking-tight text-gray-900 sm:text-4xl">
            A better way to connect
          </p>
          <p className="mt-4 max-w-2xl text-xl text-gray-500 lg:mx-auto">
            Our platform leverages cutting-edge AI and blockchain technology to create meaningful connections between
            students and alumni.
          </p>
        </div>

        <div className="mt-10">
          <dl className="space-y-10 md:space-y-0 md:grid md:grid-cols-2 md:gap-x-8 md:gap-y-10">
            {features.map((feature) => (
              <div key={feature.name} className="relative">
                <dt>
                  <div className="absolute flex items-center justify-center h-12 w-12 rounded-md bg-primary text-white">
                    <feature.icon className="h-6 w-6" aria-hidden="true" />
                  </div>
                  <p className="ml-16 text-lg leading-6 font-medium text-gray-900">{feature.name}</p>
                </dt>
                <dd className="mt-2 ml-16 text-base text-gray-500">{feature.description}</dd>
              </div>
            ))}
          </dl>
        </div>
      </div>
    </div>
  )
}

