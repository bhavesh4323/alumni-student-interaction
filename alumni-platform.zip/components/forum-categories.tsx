import { Card, CardContent, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import Link from "next/link"
import { MessageSquare, Users, Eye, Clock } from "lucide-react"

export default function ForumCategories() {
  const categories = [
    {
      id: 1,
      name: "Career Guidance",
      description: "Discuss career paths, job opportunities, and professional development in various technical fields.",
      topics: 156,
      posts: 2345,
      latestPost: {
        title: "Transitioning from Software Development to Product Management",
        author: "Rahul Verma",
        timestamp: "2 hours ago",
        views: 87,
      },
    },
    {
      id: 2,
      name: "Technical Discussions",
      description:
        "Share knowledge, ask questions, and discuss technical topics related to programming, engineering, and more.",
      topics: 243,
      posts: 3782,
      latestPost: {
        title: "Best practices for implementing microservices architecture",
        author: "Priya Sharma",
        timestamp: "5 hours ago",
        views: 124,
      },
    },
    {
      id: 3,
      name: "Higher Education",
      description: "Discuss graduate programs, research opportunities, scholarships, and academic advancement.",
      topics: 98,
      posts: 1456,
      latestPost: {
        title: "Tips for applying to MS programs in Computer Science abroad",
        author: "Ananya Patel",
        timestamp: "1 day ago",
        views: 215,
      },
    },
    {
      id: 4,
      name: "Entrepreneurship",
      description: "Discuss startups, business ideas, funding opportunities, and entrepreneurial journeys.",
      topics: 76,
      posts: 1123,
      latestPost: {
        title: "How I bootstrapped my tech startup after graduation",
        author: "Vikram Singh",
        timestamp: "3 days ago",
        views: 342,
      },
    },
    {
      id: 5,
      name: "Industry Trends",
      description: "Discuss emerging technologies, industry developments, and future trends in the tech world.",
      topics: 112,
      posts: 1876,
      latestPost: {
        title: "The impact of generative AI on software engineering jobs",
        author: "Neha Gupta",
        timestamp: "12 hours ago",
        views: 198,
      },
    },
  ]

  return (
    <div className="space-y-6">
      <div className="flex justify-between items-center">
        <h2 className="text-2xl font-bold">Forum Categories</h2>
        <Link href="/forums/new" className="text-primary hover:underline text-sm font-medium">
          Create New Topic
        </Link>
      </div>

      {categories.map((category) => (
        <Card key={category.id}>
          <CardHeader className="pb-2">
            <CardTitle className="flex justify-between items-center">
              <Link href={`/forums/${category.id}`} className="hover:text-primary">
                {category.name}
              </Link>
              <Badge variant="outline" className="ml-2">
                {category.topics} topics
              </Badge>
            </CardTitle>
            <p className="text-sm text-gray-500">{category.description}</p>
          </CardHeader>
          <CardContent className="pb-2 border-t pt-4">
            <div className="flex justify-between items-center">
              <div className="flex items-center text-sm text-gray-500">
                <MessageSquare className="h-4 w-4 mr-1" />
                <span>{category.posts} posts</span>
              </div>
              <div className="flex items-center text-sm text-gray-500">
                <Users className="h-4 w-4 mr-1" />
                <span>{Math.floor(category.posts / 12)} active users</span>
              </div>
            </div>
          </CardContent>
          <CardFooter className="bg-gray-50 text-sm border-t">
            <div className="w-full">
              <div className="flex justify-between items-center">
                <Link href={`/forums/${category.id}/topic/1`} className="font-medium hover:text-primary">
                  {category.latestPost.title}
                </Link>
              </div>
              <div className="flex justify-between items-center mt-1">
                <span className="text-gray-500">by {category.latestPost.author}</span>
                <div className="flex items-center space-x-3">
                  <div className="flex items-center text-gray-500">
                    <Eye className="h-3 w-3 mr-1" />
                    <span>{category.latestPost.views}</span>
                  </div>
                  <div className="flex items-center text-gray-500">
                    <Clock className="h-3 w-3 mr-1" />
                    <span>{category.latestPost.timestamp}</span>
                  </div>
                </div>
              </div>
            </div>
          </CardFooter>
        </Card>
      ))}
    </div>
  )
}

