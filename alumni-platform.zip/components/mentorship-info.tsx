import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { CheckCircle, Clock, Calendar, Users } from "lucide-react"

export default function MentorshipInfo() {
  const benefits = [
    {
      title: "Personalized Guidance",
      description:
        "Receive tailored advice from professionals who understand your academic background and career aspirations.",
      icon: CheckCircle,
    },
    {
      title: "Industry Insights",
      description: "Gain valuable perspectives on industry trends, job market demands, and career opportunities.",
      icon: CheckCircle,
    },
    {
      title: "Skill Development",
      description: "Identify and develop the technical and soft skills needed to excel in your chosen field.",
      icon: CheckCircle,
    },
    {
      title: "Network Expansion",
      description:
        "Build meaningful professional connections that can open doors to internships and job opportunities.",
      icon: CheckCircle,
    },
  ]

  const programDetails = [
    {
      title: "Duration",
      description: "3-6 months, with option to extend",
      icon: Calendar,
    },
    {
      title: "Time Commitment",
      description: "1-4 hours per month, flexible scheduling",
      icon: Clock,
    },
    {
      title: "Format",
      description: "Virtual or in-person meetings, based on preference and location",
      icon: Users,
    },
  ]

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle>How It Works</CardTitle>
        </CardHeader>
        <CardContent>
          <ol className="space-y-4">
            <li className="flex">
              <span className="bg-primary text-primary-foreground rounded-full h-6 w-6 flex items-center justify-center text-sm mr-3 flex-shrink-0">
                1
              </span>
              <div>
                <h3 className="font-medium">Complete Your Profile</h3>
                <p className="text-sm text-gray-500">
                  Fill out the mentorship form with your interests, goals, and preferences.
                </p>
              </div>
            </li>
            <li className="flex">
              <span className="bg-primary text-primary-foreground rounded-full h-6 w-6 flex items-center justify-center text-sm mr-3 flex-shrink-0">
                2
              </span>
              <div>
                <h3 className="font-medium">AI Matching</h3>
                <p className="text-sm text-gray-500">
                  Our AI algorithm analyzes your profile and suggests compatible mentors.
                </p>
              </div>
            </li>
            <li className="flex">
              <span className="bg-primary text-primary-foreground rounded-full h-6 w-6 flex items-center justify-center text-sm mr-3 flex-shrink-0">
                3
              </span>
              <div>
                <h3 className="font-medium">Connect & Schedule</h3>
                <p className="text-sm text-gray-500">
                  Reach out to your matched mentors and schedule your first meeting.
                </p>
              </div>
            </li>
            <li className="flex">
              <span className="bg-primary text-primary-foreground rounded-full h-6 w-6 flex items-center justify-center text-sm mr-3 flex-shrink-0">
                4
              </span>
              <div>
                <h3 className="font-medium">Regular Check-ins</h3>
                <p className="text-sm text-gray-500">Meet regularly with your mentor to discuss progress and goals.</p>
              </div>
            </li>
          </ol>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Benefits of Mentorship</CardTitle>
        </CardHeader>
        <CardContent>
          <ul className="space-y-3">
            {benefits.map((benefit, index) => (
              <li key={index} className="flex">
                <benefit.icon className="h-5 w-5 text-primary mr-2 flex-shrink-0" />
                <div>
                  <h3 className="font-medium">{benefit.title}</h3>
                  <p className="text-sm text-gray-500">{benefit.description}</p>
                </div>
              </li>
            ))}
          </ul>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Program Details</CardTitle>
        </CardHeader>
        <CardContent>
          <ul className="space-y-3">
            {programDetails.map((detail, index) => (
              <li key={index} className="flex">
                <detail.icon className="h-5 w-5 text-primary mr-2 flex-shrink-0" />
                <div>
                  <h3 className="font-medium">{detail.title}</h3>
                  <p className="text-sm text-gray-500">{detail.description}</p>
                </div>
              </li>
            ))}
          </ul>
        </CardContent>
      </Card>
    </div>
  )
}

