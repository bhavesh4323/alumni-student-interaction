import { Card, CardContent, CardFooter } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Calendar, Clock, MapPin, Users } from "lucide-react"

export default function UpcomingEvents() {
  const events = [
    {
      id: 1,
      title: "Tech Career Fair 2025",
      description:
        "Connect with top employers and alumni from the tech industry. Bring your resume and be ready to network!",
      date: "March 15, 2025",
      time: "10:00 AM - 4:00 PM",
      location: "Technical Education Campus, Jaipur",
      type: "In-person",
      attendees: 120,
    },
    {
      id: 2,
      title: "AI in Healthcare: Alumni Panel Discussion",
      description:
        "Join our distinguished alumni working in healthcare AI for an insightful discussion on the future of medical technology.",
      date: "April 5, 2025",
      time: "6:00 PM - 8:00 PM",
      location: "Virtual Event",
      type: "Online",
      attendees: 85,
    },
    {
      id: 3,
      title: "Technical Skills Workshop: Cloud Computing",
      description: "Learn essential cloud computing skills from alumni working at AWS, Google Cloud, and Azure.",
      date: "April 20, 2025",
      time: "2:00 PM - 5:00 PM",
      location: "Technical Education Campus, Jodhpur",
      type: "Hybrid",
      attendees: 65,
    },
  ]

  return (
    <section className="py-12 bg-white">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="text-center">
          <h2 className="text-base text-primary font-semibold tracking-wide uppercase">Events</h2>
          <p className="mt-2 text-3xl leading-8 font-extrabold tracking-tight text-gray-900 sm:text-4xl">
            Upcoming Opportunities
          </p>
          <p className="mt-4 max-w-2xl text-xl text-gray-500 mx-auto">
            Expand your network and knowledge through events organized by alumni and the Technical Education Department.
          </p>
        </div>

        <div className="mt-10 grid gap-8 md:grid-cols-3">
          {events.map((event) => (
            <Card key={event.id} className="overflow-hidden">
              <CardContent className="p-6">
                <h3 className="text-lg font-medium text-gray-900">{event.title}</h3>
                <p className="mt-2 text-sm text-gray-500">{event.description}</p>

                <div className="mt-4 space-y-2">
                  <div className="flex items-center text-sm text-gray-500">
                    <Calendar className="h-4 w-4 mr-2 text-gray-400" />
                    {event.date}
                  </div>
                  <div className="flex items-center text-sm text-gray-500">
                    <Clock className="h-4 w-4 mr-2 text-gray-400" />
                    {event.time}
                  </div>
                  <div className="flex items-center text-sm text-gray-500">
                    <MapPin className="h-4 w-4 mr-2 text-gray-400" />
                    {event.location} ({event.type})
                  </div>
                  <div className="flex items-center text-sm text-gray-500">
                    <Users className="h-4 w-4 mr-2 text-gray-400" />
                    {event.attendees} attending
                  </div>
                </div>
              </CardContent>
              <CardFooter className="bg-gray-50 px-6 py-3">
                <Button className="w-full">Register Now</Button>
              </CardFooter>
            </Card>
          ))}
        </div>

        <div className="mt-10 text-center">
          <Button variant="outline" size="lg">
            View All Events
          </Button>
        </div>
      </div>
    </section>
  )
}

