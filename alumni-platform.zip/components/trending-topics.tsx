import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import Link from "next/link"
import { TrendingUp, MessageSquare, Eye } from "lucide-react"

export default function TrendingTopics() {
  const trendingTopics = [
    {
      id: 1,
      title: "How to prepare for technical interviews at FAANG companies",
      category: "Career Guidance",
      replies: 34,
      views: 876,
      isHot: true,
    },
    {
      id: 2,
      title: "Best resources to learn AI and Machine Learning in 2025",
      category: "Technical Discussions",
      replies: 28,
      views: 742,
      isHot: true,
    },
    {
      id: 3,
      title: "Experiences with remote work in tech companies post-pandemic",
      category: "Industry Trends",
      replies: 22,
      views: 615,
      isHot: false,
    },
    {
      id: 4,
      title: "Scholarships for pursuing MS in Computer Science abroad",
      category: "Higher Education",
      replies: 19,
      views: 583,
      isHot: false,
    },
    {
      id: 5,
      title: "How I secured funding for my tech startup",
      category: "Entrepreneurship",
      replies: 17,
      views: 521,
      isHot: false,
    },
  ]

  const activeUsers = [
    { id: 1, name: "Priya Sharma", posts: 156, isAlumni: true },
    { id: 2, name: "Rahul Verma", posts: 132, isAlumni: true },
    { id: 3, name: "Ananya Patel", posts: 98, isAlumni: true },
    { id: 4, name: "Arjun Kumar", posts: 87, isAlumni: false },
    { id: 5, name: "Neha Gupta", posts: 76, isAlumni: false },
  ]

  return (
    <div className="space-y-6">
      <Card>
        <CardHeader>
          <CardTitle className="flex items-center">
            <TrendingUp className="h-5 w-5 mr-2 text-primary" />
            Trending Topics
          </CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          {trendingTopics.map((topic) => (
            <div key={topic.id} className="border-b pb-3 last:border-0 last:pb-0">
              <Link href={`/forums/topic/${topic.id}`} className="font-medium hover:text-primary block">
                {topic.title}
                {topic.isHot && (
                  <Badge variant="destructive" className="ml-2">
                    Hot
                  </Badge>
                )}
              </Link>
              <div className="flex justify-between items-center mt-1 text-sm">
                <span className="text-gray-500">{topic.category}</span>
                <div className="flex items-center space-x-3">
                  <div className="flex items-center text-gray-500">
                    <MessageSquare className="h-3 w-3 mr-1" />
                    <span>{topic.replies}</span>
                  </div>
                  <div className="flex items-center text-gray-500">
                    <Eye className="h-3 w-3 mr-1" />
                    <span>{topic.views}</span>
                  </div>
                </div>
              </div>
            </div>
          ))}
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Active Members</CardTitle>
        </CardHeader>
        <CardContent className="space-y-3">
          {activeUsers.map((user) => (
            <div key={user.id} className="flex justify-between items-center">
              <Link href={`/profile/${user.id}`} className="flex items-center">
                <span className="font-medium hover:text-primary">{user.name}</span>
                {user.isAlumni && (
                  <Badge variant="outline" className="ml-2 text-xs">
                    Alumni
                  </Badge>
                )}
              </Link>
              <span className="text-sm text-gray-500">{user.posts} posts</span>
            </div>
          ))}
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Forum Statistics</CardTitle>
        </CardHeader>
        <CardContent className="space-y-2">
          <div className="flex justify-between">
            <span className="text-gray-500">Total Topics:</span>
            <span className="font-medium">685</span>
          </div>
          <div className="flex justify-between">
            <span className="text-gray-500">Total Posts:</span>
            <span className="font-medium">10,582</span>
          </div>
          <div className="flex justify-between">
            <span className="text-gray-500">Registered Users:</span>
            <span className="font-medium">2,347</span>
          </div>
          <div className="flex justify-between">
            <span className="text-gray-500">Active Discussions:</span>
            <span className="font-medium">124</span>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}

