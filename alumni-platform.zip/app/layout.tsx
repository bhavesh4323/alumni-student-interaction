import type React from "react"
import "./globals.css"
import type { Metadata } from "next"
import { Inter } from "next/font/google"
import { ThemeProvider } from "@/components/theme-provider"
import AIChatbot from "@/components/ai-chatbot"

const inter = Inter({ subsets: ["latin"] })

export const metadata: Metadata = {
  title: "TechAlumni Rajasthan - Alumni-Student Interaction Platform",
  description:
    "AI-powered platform connecting students with alumni for mentorship, networking, and career guidance in the Technical Education Department, Government of Rajasthan.",
    generator: 'v0.dev'
}

export default function RootLayout({
  children,
}: {
  children: React.ReactNode
}) {
  return (
    <html lang="en">
      <body className={inter.className}>
        <ThemeProvider attribute="class" defaultTheme="light" enableSystem>
          {children}
          <AIChatbot />
        </ThemeProvider>
      </body>
    </html>
  )
}



import './globals.css'