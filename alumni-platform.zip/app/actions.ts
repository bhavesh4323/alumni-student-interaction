"use server"

import { findMatchingMentors } from "@/lib/ai-matching"

export async function findMentors(formData: FormData) {
  try {
    // Extract form data
    const careerStage = formData.get("careerStage") as string
    const interests = (formData.get("interests") as string).split(",").map((i) => i.trim())
    const skills = (formData.get("skills") as string).split(",").map((s) => s.trim())
    const goals = formData.get("goals") as string
    const preferredIndustry = formData.get("preferredIndustry") as string
    const commitmentLevel = Number.parseInt(formData.get("commitmentLevel") as string)
    const isVirtualOk = formData.get("isVirtualOk") === "on"

    // Process with AI matching
    const matches = await findMatchingMentors({
      interests,
      skills,
      industry: preferredIndustry,
    })

    return {
      success: true,
      matches: matches.slice(0, 3), // Return top 3 matches
    }
  } catch (error) {
    console.error("Error finding mentors:", error)
    return {
      success: false,
      error: "Failed to find mentors. Please try again later.",
    }
  }
}

export async function submitForumPost(formData: FormData) {
  try {
    // Extract form data
    const title = formData.get("title") as string
    const content = formData.get("content") as string
    const category = formData.get("category") as string

    // In a real app, you would save this to a database
    // For demo purposes, we'll just return success

    return {
      success: true,
      message: "Your post has been submitted successfully!",
      post: {
        id: Date.now().toString(),
        title,
        content,
        category,
        createdAt: new Date(),
      },
    }
  } catch (error) {
    console.error("Error submitting forum post:", error)
    return {
      success: false,
      error: "Failed to submit your post. Please try again later.",
    }
  }
}

