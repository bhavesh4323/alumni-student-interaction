"use client"

import type React from "react"

import { useState } from "react"
import { useRouter } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Alert, AlertDescription } from "@/components/ui/alert"
import Header from "@/components/header"
import Footer from "@/components/footer"
import { submitForumPost } from "@/app/actions"
import { moderateContent } from "@/lib/content-moderation"

export default function NewForumPostPage() {
  const router = useRouter()
  const [formData, setFormData] = useState({
    title: "",
    content: "",
    category: "",
  })
  const [isSubmitting, setIsSubmitting] = useState(false)
  const [error, setError] = useState<string | null>(null)
  const [moderationStatus, setModerationStatus] = useState<"idle" | "checking" | "approved" | "flagged" | "rejected">(
    "idle",
  )

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target
    setFormData((prev) => ({ ...prev, [name]: value }))
  }

  const handleSelectChange = (name: string, value: string) => {
    setFormData((prev) => ({ ...prev, [name]: value }))
  }

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()
    setIsSubmitting(true)
    setError(null)
    setModerationStatus("checking")

    try {
      // First, moderate the content
      const moderationResult = await moderateContent(
        formData.content,
        "forum_post",
        "Current User", // In a real app, this would be the current user's name
      )

      if (moderationResult.moderationStatus === "rejected") {
        setModerationStatus("rejected")
        throw new Error(`Your post was rejected due to: ${moderationResult.moderationReason}`)
      }

      if (moderationResult.moderationStatus === "flagged") {
        setModerationStatus("flagged")
        // In a real app, you might want to show a warning but still allow submission
      } else {
        setModerationStatus("approved")
      }

      // Create FormData object
      const formDataObj = new FormData()
      formDataObj.append("title", formData.title)
      formDataObj.append("content", formData.content)
      formDataObj.append("category", formData.category)

      // Submit the post
      const result = await submitForumPost(formDataObj)

      if (result.success) {
        // Redirect to the forum page
        router.push("/forums")
      } else {
        throw new Error(result.error || "Failed to submit post")
      }
    } catch (error) {
      setError(error instanceof Error ? error.message : "An error occurred")
    } finally {
      setIsSubmitting(false)
    }
  }

  return (
    <div className="min-h-screen flex flex-col">
      <Header />
      <main className="flex-grow py-12 px-4 sm:px-6 lg:px-8">
        <div className="max-w-3xl mx-auto">
          <Card>
            <CardHeader>
              <CardTitle>Create New Forum Post</CardTitle>
            </CardHeader>
            <CardContent>
              {error && (
                <Alert variant="destructive" className="mb-4">
                  <AlertDescription>{error}</AlertDescription>
                </Alert>
              )}

              {moderationStatus === "flagged" && (
                <Alert className="mb-4 bg-yellow-50 border-yellow-200">
                  <AlertDescription className="text-yellow-800">
                    Your post contains content that may violate our community guidelines. Please review and edit if
                    necessary.
                  </AlertDescription>
                </Alert>
              )}

              <form onSubmit={handleSubmit} className="space-y-4">
                <div className="space-y-2">
                  <Label htmlFor="category">Category</Label>
                  <Select
                    onValueChange={(value) => handleSelectChange("category", value)}
                    value={formData.category}
                    required
                  >
                    <SelectTrigger id="category">
                      <SelectValue placeholder="Select a category" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="career">Career Guidance</SelectItem>
                      <SelectItem value="technical">Technical Discussions</SelectItem>
                      <SelectItem value="education">Higher Education</SelectItem>
                      <SelectItem value="entrepreneurship">Entrepreneurship</SelectItem>
                      <SelectItem value="industry">Industry Trends</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="title">Title</Label>
                  <Input
                    id="title"
                    name="title"
                    value={formData.title}
                    onChange={handleChange}
                    placeholder="Enter a descriptive title for your post"
                    required
                  />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="content">Content</Label>
                  <Textarea
                    id="content"
                    name="content"
                    value={formData.content}
                    onChange={handleChange}
                    placeholder="Share your thoughts, questions, or insights..."
                    rows={10}
                    required
                  />
                </div>

                <div className="flex justify-end space-x-2">
                  <Button
                    type="button"
                    variant="outline"
                    onClick={() => router.push("/forums")}
                    disabled={isSubmitting}
                  >
                    Cancel
                  </Button>
                  <Button type="submit" disabled={isSubmitting || moderationStatus === "rejected"}>
                    {isSubmitting
                      ? moderationStatus === "checking"
                        ? "Checking content..."
                        : "Submitting..."
                      : "Submit Post"}
                  </Button>
                </div>
              </form>
            </CardContent>
            <CardFooter className="text-sm text-gray-500">
              All posts are subject to content moderation and must adhere to our community guidelines.
            </CardFooter>
          </Card>
        </div>
      </main>
      <Footer />
    </div>
  )
}

