import { Suspense } from "react"
import Header from "@/components/header"
import Footer from "@/components/footer"
import ForumCategories from "@/components/forum-categories"
import TrendingTopics from "@/components/trending-topics"
import Loading from "@/components/loading"

export default function ForumsPage() {
  return (
    <div className="min-h-screen bg-gray-50 flex flex-col">
      <Header />
      <main className="flex-grow">
        <div className="max-w-7xl mx-auto py-12 px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h1 className="text-3xl font-extrabold text-gray-900 sm:text-4xl">Discussion Forums</h1>
            <p className="mt-4 text-xl text-gray-500 max-w-3xl mx-auto">
              Connect with alumni and students, ask questions, share knowledge, and participate in meaningful
              discussions.
            </p>
          </div>

          <div className="grid md:grid-cols-3 gap-8">
            <div className="md:col-span-2">
              <Suspense fallback={<Loading />}>
                <ForumCategories />
              </Suspense>
            </div>
            <div>
              <Suspense fallback={<Loading />}>
                <TrendingTopics />
              </Suspense>
            </div>
          </div>
        </div>
      </main>
      <Footer />
    </div>
  )
}

