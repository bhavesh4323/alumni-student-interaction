import { Suspense } from "react"
import Header from "@/components/header"
import Hero from "@/components/hero"
import Features from "@/components/features"
import AlumniSpotlight from "@/components/alumni-spotlight"
import UpcomingEvents from "@/components/upcoming-events"
import Footer from "@/components/footer"
import Loading from "@/components/loading"

export default function HomePage() {
  return (
    <div className="min-h-screen bg-gray-50">
      <Header />
      <main>
        <Suspense fallback={<Loading />}>
          <Hero />
        </Suspense>
        <Suspense fallback={<Loading />}>
          <Features />
        </Suspense>
        <Suspense fallback={<Loading />}>
          <AlumniSpotlight />
        </Suspense>
        <Suspense fallback={<Loading />}>
          <UpcomingEvents />
        </Suspense>
      </main>
      <Footer />
    </div>
  )
}

