import { Suspense } from "react"
import Header from "@/components/header"
import Footer from "@/components/footer"
import MentorshipForm from "@/components/mentorship-form"
import MentorshipInfo from "@/components/mentorship-info"
import Loading from "@/components/loading"

export default function MentorshipPage() {
  return (
    <div className="min-h-screen bg-gray-50 flex flex-col">
      <Header />
      <main className="flex-grow">
        <div className="max-w-7xl mx-auto py-12 px-4 sm:px-6 lg:px-8">
          <div className="text-center mb-12">
            <h1 className="text-3xl font-extrabold text-gray-900 sm:text-4xl">AI-Powered Mentorship Program</h1>
            <p className="mt-4 text-xl text-gray-500 max-w-3xl mx-auto">
              Connect with alumni mentors who can guide you through your academic and professional journey.
            </p>
          </div>

          <div className="grid md:grid-cols-2 gap-12">
            <Suspense fallback={<Loading />}>
              <MentorshipInfo />
            </Suspense>
            <Suspense fallback={<Loading />}>
              <MentorshipForm />
            </Suspense>
          </div>
        </div>
      </main>
      <Footer />
    </div>
  )
}

