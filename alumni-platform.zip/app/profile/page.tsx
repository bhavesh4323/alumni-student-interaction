"use client"

import type React from "react"

import { useState } from "react"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { Label } from "@/components/ui/label"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Badge } from "@/components/ui/badge"
import { Switch } from "@/components/ui/switch"
import Header from "@/components/header"
import Footer from "@/components/footer"
import { User, Briefcase, GraduationCap, MapPin, Edit, Shield, MessageSquare, Phone } from "lucide-react"

export default function ProfilePage() {
  const [isEditing, setIsEditing] = useState(false)
  const [profile, setProfile] = useState({
    name: "Rahul Verma",
    role: "alumni",
    title: "Product Manager",
    company: "Microsoft",
    department: "Computer Science",
    graduationYear: "2012",
    location: "Hyderabad",
    bio: "Product Manager at Microsoft with a background in software development. Passionate about building user-centric products and mentoring students in technology.",
    skills: ["Product Strategy", "User Research", "Roadmapping", "Team Leadership", "Scrum"],
    interests: ["Product Management", "UX Design", "Agile Methodologies", "Tech Leadership"],
    email: "rahul.verma@example.com",
    phone: "+91 9876543210",
    linkedin: "linkedin.com/in/rahulverma",
    twitter: "twitter.com/rahulverma",
    website: "rahulverma.com",
    availableForMentoring: true,
  })

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target
    setProfile((prev) => ({ ...prev, [name]: value }))
  }

  const handleSave = () => {
    // In a real app, you would save the profile to the database
    setIsEditing(false)
  }

  return (
    <div className="min-h-screen flex flex-col">
      <Header />
      <main className="flex-grow py-12 px-4 sm:px-6 lg:px-8">
        <div className="max-w-7xl mx-auto">
          <div className="flex flex-col md:flex-row gap-8">
            {/* Profile Sidebar */}
            <div className="w-full md:w-1/3">
              <Card>
                <CardContent className="p-6">
                  <div className="flex flex-col items-center text-center">
                    <Avatar className="h-32 w-32 mb-4">
                      <AvatarImage src="/placeholder.svg?height=128&width=128" alt={profile.name} />
                      <AvatarFallback>
                        {profile.name
                          .split(" ")
                          .map((n) => n[0])
                          .join("")}
                      </AvatarFallback>
                    </Avatar>

                    <h2 className="text-2xl font-bold">{profile.name}</h2>
                    <p className="text-gray-500">
                      {profile.title} at {profile.company}
                    </p>

                    <Badge className="mt-2" variant={profile.role === "alumni" ? "default" : "secondary"}>
                      {profile.role === "alumni" ? "Alumni" : "Student"}
                    </Badge>

                    {profile.availableForMentoring && (
                      <Badge variant="outline" className="mt-2 bg-green-50 text-green-700 border-green-200">
                        Available for Mentoring
                      </Badge>
                    )}

                    <div className="mt-6 space-y-3 w-full">
                      <div className="flex items-center text-sm">
                        <Briefcase className="h-4 w-4 mr-2 text-gray-400" />
                        <span>
                          {profile.title} at {profile.company}
                        </span>
                      </div>

                      <div className="flex items-center text-sm">
                        <GraduationCap className="h-4 w-4 mr-2 text-gray-400" />
                        <span>
                          {profile.department}, Class of {profile.graduationYear}
                        </span>
                      </div>

                      <div className="flex items-center text-sm">
                        <MapPin className="h-4 w-4 mr-2 text-gray-400" />
                        <span>{profile.location}</span>
                      </div>

                      <div className="flex items-center text-sm">
                        <Shield className="h-4 w-4 mr-2 text-gray-400" />
                        <span>Blockchain Verified Profile</span>
                      </div>
                    </div>

                    <div className="mt-6 w-full">
                      <Button className="w-full">
                        <MessageSquare className="h-4 w-4 mr-2" />
                        Send Message
                      </Button>
                    </div>
                  </div>
                </CardContent>
              </Card>
            </div>

            {/* Profile Content */}
            <div className="w-full md:w-2/3">
              <Tabs defaultValue="about">
                <TabsList className="mb-4">
                  <TabsTrigger value="about">About</TabsTrigger>
                  <TabsTrigger value="activity">Activity</TabsTrigger>
                  <TabsTrigger value="mentorship">Mentorship</TabsTrigger>
                  <TabsTrigger value="settings">Settings</TabsTrigger>
                </TabsList>

                <TabsContent value="about">
                  <Card>
                    <CardHeader className="flex flex-row items-center justify-between">
                      <div>
                        <CardTitle>About</CardTitle>
                        <CardDescription>Personal and professional information</CardDescription>
                      </div>
                      <Button variant="outline" size="sm" onClick={() => setIsEditing(!isEditing)}>
                        <Edit className="h-4 w-4 mr-2" />
                        {isEditing ? "Cancel" : "Edit Profile"}
                      </Button>
                    </CardHeader>

                    <CardContent>
                      {isEditing ? (
                        <div className="space-y-4">
                          <div className="space-y-2">
                            <Label htmlFor="bio">Bio</Label>
                            <Textarea id="bio" name="bio" value={profile.bio} onChange={handleChange} rows={4} />
                          </div>

                          <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                            <div className="space-y-2">
                              <Label htmlFor="title">Job Title</Label>
                              <Input id="title" name="title" value={profile.title} onChange={handleChange} />
                            </div>

                            <div className="space-y-2">
                              <Label htmlFor="company">Company</Label>
                              <Input id="company" name="company" value={profile.company} onChange={handleChange} />
                            </div>

                            <div className="space-y-2">
                              <Label htmlFor="location">Location</Label>
                              <Input id="location" name="location" value={profile.location} onChange={handleChange} />
                            </div>

                            <div className="space-y-2">
                              <Label htmlFor="email">Email</Label>
                              <Input
                                id="email"
                                name="email"
                                type="email"
                                value={profile.email}
                                onChange={handleChange}
                              />
                            </div>
                          </div>

                          <Button onClick={handleSave}>Save Changes</Button>
                        </div>
                      ) : (
                        <div className="space-y-6">
                          <div>
                            <h3 className="font-medium">Bio</h3>
                            <p className="mt-2 text-gray-600">{profile.bio}</p>
                          </div>

                          <div>
                            <h3 className="font-medium">Skills</h3>
                            <div className="mt-2 flex flex-wrap gap-2">
                              {profile.skills.map((skill, index) => (
                                <Badge key={index} variant="secondary">
                                  {skill}
                                </Badge>
                              ))}
                            </div>
                          </div>

                          <div>
                            <h3 className="font-medium">Interests</h3>
                            <div className="mt-2 flex flex-wrap gap-2">
                              {profile.interests.map((interest, index) => (
                                <Badge key={index} variant="outline">
                                  {interest}
                                </Badge>
                              ))}
                            </div>
                          </div>

                          <div>
                            <h3 className="font-medium">Contact Information</h3>
                            <div className="mt-2 space-y-2">
                              <p className="text-sm flex items-center">
                                <User className="h-4 w-4 mr-2 text-gray-400" />
                                {profile.email}
                              </p>
                              {profile.phone && (
                                <p className="text-sm flex items-center">
                                  <Phone className="h-4 w-4 mr-2 text-gray-400" />
                                  {profile.phone}
                                </p>
                              )}
                            </div>
                          </div>
                        </div>
                      )}
                    </CardContent>
                  </Card>
                </TabsContent>

                <TabsContent value="activity">
                  <Card>
                    <CardHeader>
                      <CardTitle>Activity</CardTitle>
                      <CardDescription>Your recent activity on the platform</CardDescription>
                    </CardHeader>
                    <CardContent>
                      <div className="space-y-4">
                        <div className="border-l-2 border-primary pl-4 py-2">
                          <p className="text-sm text-gray-500">Yesterday</p>
                          <p className="font-medium">
                            Posted in forum: "Best practices for implementing microservices architecture"
                          </p>
                        </div>
                        <div className="border-l-2 border-gray-200 pl-4 py-2">
                          <p className="text-sm text-gray-500">3 days ago</p>
                          <p className="font-medium">Registered for event: "Tech Career Fair 2025"</p>
                        </div>
                        <div className="border-l-2 border-gray-200 pl-4 py-2">
                          <p className="text-sm text-gray-500">1 week ago</p>
                          <p className="font-medium">Started mentoring: Arjun Kumar</p>
                        </div>
                        <div className="border-l-2 border-gray-200 pl-4 py-2">
                          <p className="text-sm text-gray-500">2 weeks ago</p>
                          <p className="font-medium">Updated profile information</p>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                </TabsContent>

                <TabsContent value="mentorship">
                  <Card>
                    <CardHeader>
                      <CardTitle>Mentorship</CardTitle>
                      <CardDescription>Your mentorship connections and requests</CardDescription>
                    </CardHeader>
                    <CardContent>
                      <div className="space-y-6">
                        <div>
                          <h3 className="font-medium mb-3">Current Mentees (3)</h3>
                          <div className="space-y-3">
                            <div className="flex items-center justify-between">
                              <div className="flex items-center">
                                <Avatar className="h-10 w-10 mr-3">
                                  <AvatarFallback>AK</AvatarFallback>
                                </Avatar>
                                <div>
                                  <p className="font-medium">Arjun Kumar</p>
                                  <p className="text-sm text-gray-500">Computer Science, 3rd Year</p>
                                </div>
                              </div>
                              <Button variant="outline" size="sm">
                                Message
                              </Button>
                            </div>

                            <div className="flex items-center justify-between">
                              <div className="flex items-center">
                                <Avatar className="h-10 w-10 mr-3">
                                  <AvatarFallback>SP</AvatarFallback>
                                </Avatar>
                                <div>
                                  <p className="font-medium">Sneha Patel</p>
                                  <p className="text-sm text-gray-500">Information Technology, 4th Year</p>
                                </div>
                              </div>
                              <Button variant="outline" size="sm">
                                Message
                              </Button>
                            </div>

                            <div className="flex items-center justify-between">
                              <div className="flex items-center">
                                <Avatar className="h-10 w-10 mr-3">
                                  <AvatarFallback>RJ</AvatarFallback>
                                </Avatar>
                                <div>
                                  <p className="font-medium">Raj Joshi</p>
                                  <p className="text-sm text-gray-500">Electronics, 2nd Year</p>
                                </div>
                              </div>
                              <Button variant="outline" size="sm">
                                Message
                              </Button>
                            </div>
                          </div>
                        </div>

                        <div>
                          <h3 className="font-medium mb-3">Pending Requests (2)</h3>
                          <div className="space-y-3">
                            <div className="flex items-center justify-between">
                              <div className="flex items-center">
                                <Avatar className="h-10 w-10 mr-3">
                                  <AvatarFallback>AM</AvatarFallback>
                                </Avatar>
                                <div>
                                  <p className="font-medium">Ankit Mishra</p>
                                  <p className="text-sm text-gray-500">Computer Science, 2nd Year</p>
                                </div>
                              </div>
                              <div className="flex space-x-2">
                                <Button size="sm" variant="default">
                                  Accept
                                </Button>
                                <Button size="sm" variant="outline">
                                  Decline
                                </Button>
                              </div>
                            </div>

                            <div className="flex items-center justify-between">
                              <div className="flex items-center">
                                <Avatar className="h-10 w-10 mr-3">
                                  <AvatarFallback>PG</AvatarFallback>
                                </Avatar>
                                <div>
                                  <p className="font-medium">Priya Gupta</p>
                                  <p className="text-sm text-gray-500">Information Technology, 3rd Year</p>
                                </div>
                              </div>
                              <div className="flex space-x-2">
                                <Button size="sm" variant="default">
                                  Accept
                                </Button>
                                <Button size="sm" variant="outline">
                                  Decline
                                </Button>
                              </div>
                            </div>
                          </div>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                </TabsContent>

                <TabsContent value="settings">
                  <Card>
                    <CardHeader>
                      <CardTitle>Settings</CardTitle>
                      <CardDescription>Manage your account settings and preferences</CardDescription>
                    </CardHeader>
                    <CardContent>
                      <div className="space-y-6">
                        <div className="space-y-2">
                          <h3 className="font-medium">Mentorship Preferences</h3>
                          <div className="flex items-center justify-between">
                            <div>
                              <p>Available for Mentoring</p>
                              <p className="text-sm text-gray-500">Allow students to request mentorship</p>
                            </div>
                            <Switch checked={profile.availableForMentoring} />
                          </div>
                        </div>

                        <div className="space-y-2">
                          <h3 className="font-medium">Notification Settings</h3>
                          <div className="space-y-3">
                            <div className="flex items-center justify-between">
                              <div>
                                <p>Email Notifications</p>
                                <p className="text-sm text-gray-500">Receive updates via email</p>
                              </div>
                              <Switch defaultChecked />
                            </div>

                            <div className="flex items-center justify-between">
                              <div>
                                <p>Mentorship Requests</p>
                                <p className="text-sm text-gray-500">Get notified about new mentorship requests</p>
                              </div>
                              <Switch defaultChecked />
                            </div>

                            <div className="flex items-center justify-between">
                              <div>
                                <p>Forum Activity</p>
                                <p className="text-sm text-gray-500">Get notified about replies to your posts</p>
                              </div>
                              <Switch defaultChecked />
                            </div>

                            <div className="flex items-center justify-between">
                              <div>
                                <p>Event Reminders</p>
                                <p className="text-sm text-gray-500">Get reminders about upcoming events</p>
                              </div>
                              <Switch defaultChecked />
                            </div>
                          </div>
                        </div>

                        <div className="pt-4 border-t">
                          <Button variant="destructive">Delete Account</Button>
                        </div>
                      </div>
                    </CardContent>
                  </Card>
                </TabsContent>
              </Tabs>
            </div>
          </div>
        </div>
      </main>
      <Footer />
    </div>
  )
}

