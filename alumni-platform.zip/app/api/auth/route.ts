import { NextResponse } from "next/server"

export async function POST(request: Request) {
  try {
    const { email, password } = await request.json()

    // In a real app, you would validate credentials against a database
    // For demo purposes, we'll accept any login with a valid email format
    if (!email || !email.includes("@") || !password || password.length < 6) {
      return NextResponse.json({ success: false, message: "Invalid credentials" }, { status: 400 })
    }

    // Simulate successful authentication
    return NextResponse.json({
      success: true,
      user: {
        id: "1",
        name: email.split("@")[0],
        email,
        role: email.includes("alumni") ? "alumni" : "student",
      },
    })
  } catch (error) {
    return NextResponse.json({ success: false, message: "Authentication failed" }, { status: 500 })
  }
}

