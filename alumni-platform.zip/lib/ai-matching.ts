// This is a simplified simulation of an AI matching service
// In a real implementation, this would use NLP and ML algorithms

export interface MatchingProfile {
  id: string
  name: string
  role: "student" | "alumni" | "faculty"
  interests: string[]
  skills: string[]
  industry: string
  experience: number // years
  department: string
  graduationYear?: number
  location: string
  bio: string
  availableForMentoring?: boolean
  mentorshipPreferences?: {
    format: "virtual" | "in-person" | "both"
    frequency: "weekly" | "biweekly" | "monthly"
    duration: number // months
  }
  profileImage?: string
}

// Calculate similarity score between two profiles
function calculateSimilarityScore(profile1: MatchingProfile, profile2: MatchingProfile): number {
  let score = 0

  // Interest matching (highest weight)
  const interestOverlap = profile1.interests.filter((interest) => profile2.interests.includes(interest)).length
  score += (interestOverlap / Math.max(profile1.interests.length, profile2.interests.length)) * 40

  // Skill matching
  const skillOverlap = profile1.skills.filter((skill) => profile2.skills.includes(skill)).length
  score += (skillOverlap / Math.max(profile1.skills.length, profile2.skills.length)) * 30

  // Industry matching
  if (profile1.industry === profile2.industry) {
    score += 15
  }

  // Department matching
  if (profile1.department === profile2.department) {
    score += 10
  }

  // Location bonus (small bonus for same location)
  if (profile1.location === profile2.location) {
    score += 5
  }

  return Math.min(score, 100) // Cap at 100
}

// Mock alumni profiles for matching
const mockAlumniProfiles: MatchingProfile[] = [
  {
    id: "1",
    name: "Priya Sharma",
    role: "alumni",
    interests: ["Artificial Intelligence", "Machine Learning", "Data Science", "Cloud Computing"],
    skills: ["Python", "TensorFlow", "PyTorch", "Google Cloud", "Data Analysis"],
    industry: "Technology",
    experience: 7,
    department: "Computer Science",
    graduationYear: 2015,
    location: "Bangalore",
    bio: "Machine Learning Engineer at Google with expertise in building AI solutions for enterprise applications.",
    availableForMentoring: true,
    mentorshipPreferences: {
      format: "both",
      frequency: "biweekly",
      duration: 6,
    },
    profileImage: "/placeholder.svg?height=200&width=200",
  },
  {
    id: "2",
    name: "Rahul Verma",
    role: "alumni",
    interests: ["Product Management", "UX Design", "Agile Methodologies", "Tech Leadership"],
    skills: ["Product Strategy", "User Research", "Roadmapping", "Team Leadership", "Scrum"],
    industry: "Technology",
    experience: 10,
    department: "Computer Science",
    graduationYear: 2012,
    location: "Hyderabad",
    bio: "Product Manager at Microsoft with a background in software development. Passionate about building user-centric products.",
    availableForMentoring: true,
    mentorshipPreferences: {
      format: "virtual",
      frequency: "monthly",
      duration: 3,
    },
    profileImage: "/placeholder.svg?height=200&width=200",
  },
  {
    id: "3",
    name: "Ananya Patel",
    role: "alumni",
    interests: ["Data Science", "Big Data", "Business Intelligence", "E-commerce"],
    skills: ["Python", "SQL", "Tableau", "AWS", "Hadoop", "Spark"],
    industry: "E-commerce",
    experience: 5,
    department: "Information Technology",
    graduationYear: 2017,
    location: "Mumbai",
    bio: "Data Scientist at Amazon working on recommendation systems and customer behavior analysis.",
    availableForMentoring: true,
    mentorshipPreferences: {
      format: "both",
      frequency: "biweekly",
      duration: 4,
    },
    profileImage: "/placeholder.svg?height=200&width=200",
  },
  {
    id: "4",
    name: "Vikram Singh",
    role: "alumni",
    interests: ["Entrepreneurship", "Startups", "Blockchain", "FinTech", "Venture Capital"],
    skills: ["Business Development", "Fundraising", "Marketing", "JavaScript", "Solidity"],
    industry: "Finance",
    experience: 8,
    department: "Electronics",
    graduationYear: 2014,
    location: "Delhi",
    bio: "Founder of a FinTech startup after working at Goldman Sachs. Raised $2M in seed funding.",
    availableForMentoring: true,
    mentorshipPreferences: {
      format: "virtual",
      frequency: "monthly",
      duration: 6,
    },
    profileImage: "/placeholder.svg?height=200&width=200",
  },
  {
    id: "5",
    name: "Neha Gupta",
    role: "alumni",
    interests: ["Cybersecurity", "Ethical Hacking", "Network Security", "Cloud Security"],
    skills: ["Penetration Testing", "Security Auditing", "Python", "Linux", "AWS Security"],
    industry: "Cybersecurity",
    experience: 6,
    department: "Information Technology",
    graduationYear: 2016,
    location: "Pune",
    bio: "Security Engineer at IBM specializing in cloud security and vulnerability assessment.",
    availableForMentoring: true,
    mentorshipPreferences: {
      format: "both",
      frequency: "biweekly",
      duration: 3,
    },
    profileImage: "/placeholder.svg?height=200&width=200",
  },
]

// Find matching mentors for a student profile
export async function findMatchingMentors(studentProfile: Partial<MatchingProfile>): Promise<
  {
    mentor: MatchingProfile
    matchScore: number
    compatibilityReason: string
  }[]
> {
  // Simulate processing delay
  await new Promise((resolve) => setTimeout(resolve, 1500))

  // Create a complete profile from partial data
  const completeStudentProfile: MatchingProfile = {
    id: "student_" + Date.now(),
    name: studentProfile.name || "Student",
    role: "student",
    interests: studentProfile.interests || [],
    skills: studentProfile.skills || [],
    industry: studentProfile.industry || "",
    experience: 0,
    department: studentProfile.department || "",
    location: studentProfile.location || "",
    bio: studentProfile.bio || "",
  }

  // Calculate match scores for each alumni
  const matches = mockAlumniProfiles
    .filter((alumni) => alumni.availableForMentoring)
    .map((alumni) => {
      const matchScore = calculateSimilarityScore(completeStudentProfile, alumni)

      // Generate compatibility reason based on highest matching factors
      let compatibilityReason = ""

      const interestOverlap = completeStudentProfile.interests.filter((interest) => alumni.interests.includes(interest))

      const skillOverlap = completeStudentProfile.skills.filter((skill) => alumni.skills.includes(skill))

      if (interestOverlap.length > 0) {
        compatibilityReason = `Shared interests in ${interestOverlap.slice(0, 2).join(", ")}`
      } else if (skillOverlap.length > 0) {
        compatibilityReason = `Complementary skills in ${skillOverlap.slice(0, 2).join(", ")}`
      } else if (completeStudentProfile.industry === alumni.industry) {
        compatibilityReason = `Both focused on the ${alumni.industry} industry`
      } else if (completeStudentProfile.department === alumni.department) {
        compatibilityReason = `Same academic background in ${alumni.department}`
      } else {
        compatibilityReason = "Diverse perspectives that complement each other"
      }

      return {
        mentor: alumni,
        matchScore,
        compatibilityReason,
      }
    })
    .sort((a, b) => b.matchScore - a.matchScore)

  return matches
}

