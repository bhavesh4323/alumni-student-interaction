// This is a simplified simulation of a content moderation service
// In a real implementation, this would use NLP for content analysis

export interface ModeratedContent {
  id: string
  content: string
  author: string
  timestamp: Date
  contentType: "forum_post" | "comment" | "message" | "profile"
  moderationStatus: "pending" | "approved" | "flagged" | "rejected"
  moderationReason?: string
  moderationScore?: number
}

// List of prohibited content patterns
const prohibitedPatterns = [
  /\b(hate|violent|threat|kill|attack)\b/i,
  /\b(scam|fraud|fake|phishing)\b/i,
  /\b(obscene|explicit|porn|xxx)\b/i,
  /\b(gamble|betting|casino)\b/i,
  /\b(illegal|hack|crack|pirate)\b/i,
]

// Check if content contains prohibited patterns
function containsProhibitedContent(content: string): boolean {
  return prohibitedPatterns.some((pattern) => pattern.test(content))
}

// Calculate moderation score (0-100, higher means more problematic)
function calculateModerationScore(content: string): number {
  let score = 0

  // Check for prohibited patterns
  prohibitedPatterns.forEach((pattern) => {
    if (pattern.test(content)) {
      score += 25 // Each match adds 25 points
    }
  })

  // Check for all caps (shouting)
  if (content.length > 10 && content === content.toUpperCase()) {
    score += 10
  }

  // Check for excessive punctuation
  if ((content.match(/!{2,}/g) || []).length > 2 || (content.match(/\?{2,}/g) || []).length > 2) {
    score += 5
  }

  // Check for excessive repetition
  if ((content.match(/(.)\1{4,}/g) || []).length > 0) {
    score += 5
  }

  return Math.min(score, 100) // Cap at 100
}

// Determine moderation status based on score
function getModerationStatus(score: number): ModeratedContent["moderationStatus"] {
  if (score >= 50) {
    return "rejected"
  } else if (score >= 25) {
    return "flagged"
  } else {
    return "approved"
  }
}

// Get moderation reason based on content analysis
function getModerationReason(content: string, score: number): string | undefined {
  if (score < 25) {
    return undefined
  }

  const reasons = []

  prohibitedPatterns.forEach((pattern, index) => {
    if (pattern.test(content)) {
      switch (index) {
        case 0:
          reasons.push("Contains potentially harmful or threatening language")
          break
        case 1:
          reasons.push("Contains potential scam or fraudulent content")
          break
        case 2:
          reasons.push("Contains potentially inappropriate or explicit content")
          break
        case 3:
          reasons.push("Contains references to gambling or betting")
          break
        case 4:
          reasons.push("Contains references to illegal activities")
          break
      }
    }
  })

  if (content.length > 10 && content === content.toUpperCase()) {
    reasons.push("Excessive use of capital letters")
  }

  if ((content.match(/!{2,}/g) || []).length > 2 || (content.match(/\?{2,}/g) || []).length > 2) {
    reasons.push("Excessive punctuation")
  }

  return reasons.join(", ")
}

// Moderate content
export async function moderateContent(
  content: string,
  contentType: ModeratedContent["contentType"],
  author: string,
): Promise<ModeratedContent> {
  // Simulate processing delay
  await new Promise((resolve) => setTimeout(resolve, 800))

  const moderationScore = calculateModerationScore(content)
  const moderationStatus = getModerationStatus(moderationScore)
  const moderationReason = getModerationReason(content, moderationScore)

  return {
    id: Date.now().toString(),
    content,
    author,
    timestamp: new Date(),
    contentType,
    moderationStatus,
    moderationReason,
    moderationScore,
  }
}

// Check if a profile is potentially fraudulent
export async function detectFraudulentProfile(profile: any): Promise<{
  isFraudulent: boolean
  confidenceScore: number
  reasons?: string[]
}> {
  // Simulate processing delay
  await new Promise((resolve) => setTimeout(resolve, 1000))

  const reasons = []
  let confidenceScore = 0

  // Check for suspicious email domains
  const suspiciousEmailDomains = ["tempmail.com", "fakeemail.com", "throwaway.com"]
  if (profile.email && suspiciousEmailDomains.some((domain) => profile.email.includes(domain))) {
    reasons.push("Suspicious email domain")
    confidenceScore += 30
  }

  // Check for inconsistent information
  if (profile.graduationYear && profile.graduationYear > new Date().getFullYear()) {
    reasons.push("Future graduation year")
    confidenceScore += 20
  }

  // Check for suspicious bio content
  if (profile.bio && containsProhibitedContent(profile.bio)) {
    reasons.push("Suspicious content in bio")
    confidenceScore += 25
  }

  // Check for missing essential information
  const missingFields = []
  if (!profile.name) missingFields.push("name")
  if (!profile.email) missingFields.push("email")
  if (!profile.institution) missingFields.push("institution")

  if (missingFields.length > 1) {
    reasons.push(`Missing essential information: ${missingFields.join(", ")}`)
    confidenceScore += 15
  }

  return {
    isFraudulent: confidenceScore >= 50,
    confidenceScore: Math.min(confidenceScore, 100),
    reasons: reasons.length > 0 ? reasons : undefined,
  }
}

