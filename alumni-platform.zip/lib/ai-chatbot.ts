// This is a simplified simulation of an AI chatbot service
// In a real implementation, this would use Rasa and spaCy for NLP

export interface ChatMessage {
  id: string
  content: string
  sender: "user" | "bot"
  timestamp: Date
}

export interface ChatSession {
  id: string
  messages: ChatMessage[]
  createdAt: Date
  updatedAt: Date
}

// Predefined intents and responses
const intents = {
  greeting: {
    patterns: ["hello", "hi", "hey", "greetings", "good morning", "good afternoon", "good evening"],
    responses: [
      "Hello! How can I assist you with the TechAlumni platform today?",
      "Hi there! What would you like to know about our alumni network?",
      "Greetings! I'm here to help you navigate our platform. What do you need?",
    ],
  },
  mentorship: {
    patterns: ["mentor", "mentorship", "guidance", "career advice", "find mentor"],
    responses: [
      "Our mentorship program connects students with alumni based on career interests and goals. Would you like me to help you find a mentor?",
      "Looking for mentorship? I can guide you through our AI-powered matching system to find the perfect mentor for your needs.",
      "Our alumni mentors provide valuable career guidance and industry insights. What specific area are you looking for mentorship in?",
    ],
  },
  events: {
    patterns: ["event", "webinar", "workshop", "meetup", "conference", "schedule"],
    responses: [
      "We have several upcoming events! The next one is the Tech Career Fair on March 15, 2025. Would you like to register?",
      "Our events calendar includes workshops, webinars, and networking opportunities. What type of event are you interested in?",
      "Alumni regularly host events both online and in-person. I can help you find events relevant to your interests.",
    ],
  },
  profile: {
    patterns: ["profile", "account", "sign up", "register", "login", "verification"],
    responses: [
      "To set up or update your profile, go to the Profile section after logging in. Make sure to add your skills and interests for better mentor matching!",
      "Your profile is secured with blockchain verification to ensure authenticity. Have you completed the verification process?",
      "A complete profile helps our AI matching system connect you with relevant alumni and opportunities. What would you like to know about profile setup?",
    ],
  },
  forums: {
    patterns: ["forum", "discussion", "post", "topic", "thread", "question"],
    responses: [
      "Our discussion forums cover various topics from career guidance to technical discussions. What topic are you interested in?",
      "You can ask questions, share knowledge, and connect with others in our moderated forums. Would you like me to show you the most active discussions?",
      "The forums are a great place to get advice from alumni who have been in your position. Have you checked out our trending topics?",
    ],
  },
  fallback: {
    responses: [
      "I'm not sure I understand. Could you rephrase your question?",
      "I'm still learning! Could you provide more details about what you're looking for?",
      "I don't have information on that yet. Would you like me to connect you with a human administrator?",
    ],
  },
}

// Simulate NLP intent detection
function detectIntent(message: string): keyof typeof intents {
  message = message.toLowerCase()

  for (const [intent, data] of Object.entries(intents)) {
    if (intent === "fallback") continue

    if (data.patterns.some((pattern) => message.includes(pattern))) {
      return intent as keyof typeof intents
    }
  }

  return "fallback"
}

// Get a random response for an intent
function getRandomResponse(intent: keyof typeof intents): string {
  const responses = intents[intent].responses
  const randomIndex = Math.floor(Math.random() * responses.length)
  return responses[randomIndex]
}

// Process a user message and generate a bot response
export async function processMessage(message: string): Promise<ChatMessage> {
  // Simulate processing delay
  await new Promise((resolve) => setTimeout(resolve, 800))

  const intent = detectIntent(message)
  const response = getRandomResponse(intent)

  return {
    id: Date.now().toString(),
    content: response,
    sender: "bot",
    timestamp: new Date(),
  }
}

// Create a new chat session
export function createChatSession(): ChatSession {
  const welcomeMessage: ChatMessage = {
    id: "1",
    content: "Hello! I'm your AI assistant for the TechAlumni platform. How can I help you today?",
    sender: "bot",
    timestamp: new Date(),
  }

  return {
    id: Date.now().toString(),
    messages: [welcomeMessage],
    createdAt: new Date(),
    updatedAt: new Date(),
  }
}

